package adt.heap;

public interface MaxHeap<T extends Comparable<T>> extends GenericHeap<T> {

}
