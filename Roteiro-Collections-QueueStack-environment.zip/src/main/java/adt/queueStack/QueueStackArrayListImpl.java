package adt.queueStack;

import java.util.ArrayList;

import adt.queue.QueueOverflowException;
import adt.queue.QueueUnderflowException;
import adt.stack.StackOverflowException;
import adt.stack.StackUnderflowException;

/**
 * Classe que implementa uma fila e uma pilha ao mesmo tempo usando apenas um arraylist sobrejacente.
 * A pilha é implementada no início do array e a fila é implementada no final do array. Assim, uma mesma estrutura 
 * (arraylist) serve para acomodar duas estruturas (pilha e fila) ao mesmo tempo. Cada estrutura (pilha e fila) 
 * pode ter um tamanho arbitrário, desde que a soma dos tamanhos delas seja no máximo o tamanho do array sobrejacente.
 *
 * @param <T> o tipo to dado armazenado na estrutura.
 */
public class QueueStackArrayListImpl<T> implements QueueStack<T> {

	/**
	 * Embora ArrayList seja uma estrutura que pode crescer dinamicamente, não será permitido esse crescimento
	 * e o tamanho inicial deverá ser respeitado.
	 */
	private ArrayList<T> array;
	private int size;
	private int top; //indica o topo da pilha
	private int tail; //indica o final da fila 
	
	public QueueStackArrayListImpl(int size) {
		this.array = new ArrayList<T>(size);
		this.size = size;
	}

	@Override
	public void push(T element) throws StackOverflowException {
		// TODO Auto-generated method stub
		throw new RuntimeException("Not implemented yet!");
	}

	@Override
	public T pop() throws StackUnderflowException {
		// TODO Auto-generated method stub
		throw new RuntimeException("Not implemented yet!");
	}

	@Override
	public T top() {
		// TODO Auto-generated method stub
		throw new RuntimeException("Not implemented yet!");
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		throw new RuntimeException("Not implemented yet!");
	}

	@Override
	public boolean isFull() {
		// TODO Auto-generated method stub
		throw new RuntimeException("Not implemented yet!");
	}

	@Override
	public void enqueue(T element) throws QueueOverflowException {
		// TODO Auto-generated method stub
		throw new RuntimeException("Not implemented yet!");
	}

	@Override
	public T dequeue() throws QueueUnderflowException {
		// TODO Auto-generated method stub
		throw new RuntimeException("Not implemented yet!");
	}

	@Override
	public T head() {
		// TODO Auto-generated method stub
		throw new RuntimeException("Not implemented yet!");
	}

}
