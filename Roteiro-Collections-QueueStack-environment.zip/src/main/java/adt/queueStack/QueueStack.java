package adt.queueStack;
import adt.queue.Queue;
import adt.stack.Stack;


public interface QueueStack<T> extends Stack<T>, Queue<T> {

}
