package adt.queue;

public class CircularQueue<T> implements Queue<T> {
	
	private T[] array;
	private int tail;
	private int head;
	private int elements;
	
	public CircularQueue(int size){
		array = (T[])new Object[size];
		head = -1;
		tail = -1;
		elements = 0;
	}
	
	@Override
	public void enqueue(T element) throws QueueOverflowException {
		// TODO Auto-generated method stub

	}

	@Override
	public T dequeue() throws QueueUnderflowException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public T head() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isFull() {
		// TODO Auto-generated method stub
		return false;
	}

}
